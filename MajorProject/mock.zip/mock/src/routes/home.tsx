import { Sparkles } from "lucide-react";
import Marquee from "react-fast-marquee";

import { Container } from "@/components/container";
import { Button } from "@/components/ui/button";
import { MarqueImg } from "@/components/marquee-img";
import { Link } from "react-router-dom";

const HomePage = () => {
  return (
    <div className="flex-col w-full pb-24">
      <Container>
        <div className="my-7">
          <h2 className="text-3xl text-center md:text-left md:text-6xl">
            <span className="font-extrabold md:text-8xl text-white"
                style={{
                textShadow: "2px 2px 4px black, -2px -2px 1px black"
              }}>
              AI Superpower
            </span>
            <span className="text-gray-500 font-extrabold">
              - A better way to
            </span>
            <br />
            <div className="mt-6">
            improve your interview chances and skills
            </div>
          </h2>

          <p className="mt-6 text-muted-foreground text-sm">
            Boost your interview skills and increase your success rate with
            AI-driven insights. Discover a smarter way to prepare, practice, and
            stand out.
          </p>
        </div>

        

        {/* image section */}
        <div className="w-full mt-4 rounded-3xl bg-gray-100 h-[420px] drop-shadow-md overflow-hidden static">
          <img
            src="/assets/img/hero.jpg"
            alt=""
            className="w-full h-full object-cover"
          />

          <div className="absolute top-4 left-4 px-4 py-2 rounded-md bg-white/40 backdrop-blur-md">
            Inteviews Copilot&copy;
          </div>

          <div className="hidden md:block absolute w-80 bottom-4 right-4 px-4 py-2 rounded-md bg-white/60 backdrop-blur-md">
            <h2 className="text-neutral-800 font-semibold">Developer</h2>
            <p className="text-sm text-neutral-500">
              A platform to explore, learn, and innovate. Connecting technology with creativity
            </p>

            <Button className="mt-3">
              Generate <Sparkles />
            </Button>
          </div>
        </div>
      </Container>

      {/* marquee section */}
      <div className=" w-full my-16">
        {/* <Marquee pauseOnHover>
          <MarqueImg img="/assets/img/logo/firebase.png" />
          <MarqueImg img="/assets/img/logo/reactjs.png" />
          <MarqueImg img="/assets/img/logo/next.png" />
          <MarqueImg img="/assets/img/logo/mongo.png" />
          <MarqueImg img="/assets/img/logo/tailwindcss.png" />
          <MarqueImg img="/assets/img/logo/microsoft.png" />
          <MarqueImg img="/assets/img/logo/gemini.png" />
          <MarqueImg img="/assets/img/logo/meet.png" />
        </Marquee> */}
      </div>

      <Container className="py-8 space-y-8">
        <h2 className="tracking-wide text-xl text-gray-800 font-semibold">
          Unleash your potential with personalized AI insights and targeted
          interview practice.
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <div className="col-span-1 md:col-span-3">
            <img
              src="/assets/img/office.jpg"
              alt=""
              className="w-full max-h-96 rounded-md object-cover"
            />
          </div>

          <div className="col-span-1 md:col-span-2 gap-8 max-h-96 min-h-96 w-full flex flex-col items-center justify-center text-center">
            <p className="text-center text-muted-foreground">
              Transform the way you prepare, gain confidence, and boost your
              chances of landing your dream job. Let AI be your edge in
              today&apos;s competitive job market.
            </p>

            <Link to={"/generate"} className="w-full">
    <Button className="w-3/4 bg-blue-800 text-white font-semibold py-4 px-8 rounded-full shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 ease-in-out transform relative overflow-hidden group">
      <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 opacity-0 group-hover:opacity-100 group-hover:scale-[1.8] transition-all duration-500 ease-in-out"></div>
      <span className="relative z-10 transition-all duration-300 group-hover:text-white">
        Generate <Sparkles className="ml-2 inline-block transition-transform duration-300 group-hover:rotate-12" />
      </span>
    </Button>
  </Link>
          </div>
        </div>
      </Container>
    </div>
  );
};


export default HomePage;